import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  IconButton,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import SaveIcon from '@mui/icons-material/Save';
import { TiptapEditorRefactored } from './TiptapEditorRefactored';

interface EditorDialogProps {
  open: boolean;
  onClose: () => void;
  initialContent?: string;
  title?: string;
}

export const EditorDialog: React.FC<EditorDialogProps> = ({
  open,
  onClose,
  initialContent = '',
  title = 'Rich Text Editor',
}) => {
  const [content, setContent] = useState(initialContent);

  const handleSave = () => {
    console.log('📝 Saved Content (HTML):', content);
    console.log('📄 Content Length:', content.length, 'characters');

    // You can add your save logic here (e.g., API call, localStorage, etc.)
    alert('Content saved! Check the console for details.');
    onClose();
  };

  const handleClose = () => {
    const hasContent = content.trim().length > 0 && content !== '<p></p>';

    if (hasContent) {
      const confirmClose = window.confirm(
        'You have unsaved changes. Are you sure you want to close?'
      );
      if (!confirmClose) return;
    }

    onClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          height: '90vh',
          maxHeight: '900px',
        },
      }}
    >
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography variant="h6" component="div">
          {title}
        </Typography>
        <IconButton
          edge="end"
          color="inherit"
          onClick={handleClose}
          aria-label="close"
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent dividers sx={{ p: 0 }}>
        <Box sx={{ height: '100%' }}>
          <TiptapEditorRefactored
            content={initialContent}
            onChange={setContent}
            placeholder="Start writing your content here..."
          />
        </Box>
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={handleClose} variant="outlined">
          Cancel
        </Button>
        <Button
          onClick={handleSave}
          variant="contained"
          startIcon={<SaveIcon />}
        >
          Save Content
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default EditorDialog;
