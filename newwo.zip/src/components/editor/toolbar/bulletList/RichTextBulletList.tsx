import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { MdFormatListBulleted } from 'react-icons/md';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextBulletList: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Bullet List">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleBulletList().run()}
        className={editor.isActive('bulletList') ? styles.isActive : ''}
      >
        <MdFormatListBulleted />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextBulletList;
