import React, { useState } from 'react';
import { IconButton, Tooltip, Popover, Box } from '@mui/material';
import { PiHighlighterBold } from 'react-icons/pi';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

const COLORS = [
  '#fef08a', '#fed7aa', '#fecaca', '#f3e8ff', '#ddd6fe', '#bfdbfe',
  '#a7f3d0', '#fde68a', '#fbb6ce', '#c7d2fe', '#d1fae5', '#fde047',
];

export const RichTextHighlight: React.FC = () => {
  const editor = useRichTextEditor();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  const handleHighlightChange = (color: string) => {
    editor.chain().focus().setHighlight({ color }).run();
    setAnchorEl(null);
  };

  return (
    <>
      <Tooltip title="Highlight">
        <IconButton
          size="small"
          onClick={(e) => setAnchorEl(e.currentTarget)}
          className={editor.isActive('highlight') ? styles.isActive : ''}
        >
          <PiHighlighterBold />
        </IconButton>
      </Tooltip>
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Box className={styles.colorPalette}>
          {COLORS.map((color) => (
            <Box
              key={color}
              className={styles.colorSwatch}
              style={{ backgroundColor: color }}
              onClick={() => handleHighlightChange(color)}
            />
          ))}
        </Box>
      </Popover>
    </>
  );
};

export default RichTextHighlight;
