import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { ImBold } from 'react-icons/im';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextBold: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Bold">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleBold().run()}
        className={editor.isActive('bold') ? styles.isActive : ''}
      >
        <ImBold />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextBold;
