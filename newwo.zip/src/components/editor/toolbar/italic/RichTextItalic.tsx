import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { ImItalic } from 'react-icons/im';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextItalic: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Italic">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleItalic().run()}
        className={editor.isActive('italic') ? styles.isActive : ''}
      >
        <ImItalic />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextItalic;
