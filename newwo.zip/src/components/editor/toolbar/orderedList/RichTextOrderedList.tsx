import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { MdFormatListNumbered } from 'react-icons/md';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextOrderedList: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Numbered List">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleOrderedList().run()}
        className={editor.isActive('orderedList') ? styles.isActive : ''}
      >
        <MdFormatListNumbered />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextOrderedList;
