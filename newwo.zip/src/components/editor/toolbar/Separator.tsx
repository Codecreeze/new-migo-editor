import React from 'react';
import { Divider } from '@mui/material';
import styles from './separator.module.scss';

export const Separator: React.FC = () => {
  return (
    <Divider 
      orientation="vertical" 
      flexItem 
      className={styles.separator}
    />
  );
};

export default Separator;
