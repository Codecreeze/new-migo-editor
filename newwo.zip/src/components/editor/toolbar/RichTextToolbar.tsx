import React from "react";
import { Box } from "@mui/material";
import {
  RichTextUndo,
  RichTextRedo,
  RichTextSearchAndReplace,
  RichTextClear,
  RichTextFontFamily,
  RichTextHeading,
  RichTextFontSize,
  RichTextBold,
  RichTextItalic,
  RichTextUnderline,
  RichTextStrike,
  RichTextSubscript,
  RichTextSuperscript,
  RichTextColor,
  RichTextHighlight,
  RichTextEmoji,
  RichTextBulletList,
  RichTextOrderedList,
  RichTextTaskList,
  RichTextAlignLeft,
  RichTextAlignCenter,
  RichTextAlignRight,
  RichTextAlignJustify,
  RichTextIndentIncrease,
  RichTextIndentDecrease,
  RichTextLineHeight,
  RichTextLink,
  RichTextImage,
  RichTextVideo,
  RichTextAttachment,
  RichTextBlockquote,
  RichTextHorizontalRule,
  RichTextCode,
  RichTextCodeBlock,
  RichTextTable,
  RichTextColumn,
  RichTextCallout,
  RichTextExportPdf,
  Separator,
} from "./index";
import styles from "../SubComponents/TiptapEditor.module.scss";


export const RichTextToolbar: React.FC = () => {
  return (
    <React.Fragment>
      {/* Toolbar */}
      <Box className={styles.toolbar}>
        {/* History & Search Group */}
        <RichTextUndo />
        <RichTextRedo />
        <RichTextSearchAndReplace />
        <RichTextClear />
        <Separator />

        {/* Typography Group */}
        <RichTextFontSize />
        <RichTextFontFamily />
        <RichTextHeading />
        <Separator />

        {/* Text Formatting Group */}
        <RichTextBold />
        <RichTextItalic />
        <RichTextUnderline />
        <RichTextStrike />
        <RichTextCode />
        <RichTextSubscript />
        <RichTextSuperscript />
        <Separator />

        {/* Color & Styling Group */}
        <RichTextEmoji />
        <RichTextColor />
        <RichTextHighlight />
        <Separator />

        {/* Lists & Alignment Group */}
        <RichTextIndentIncrease />
        <RichTextIndentDecrease />
        <RichTextLineHeight />
        <RichTextBulletList />
        <RichTextOrderedList />
        <RichTextTaskList />
        <RichTextAlignLeft />
        <RichTextAlignCenter />
        <RichTextAlignRight />
        <RichTextAlignJustify />
        <Separator />

        {/* Media & Links Group */}
        <RichTextVideo />
        <RichTextAttachment />
        <RichTextLink />
        <RichTextImage />
        <Separator />

        {/* Content Blocks Group */}
        <RichTextBlockquote />
        <RichTextHorizontalRule />
        <RichTextCodeBlock />
        <RichTextTable />
        <RichTextColumn />
        <RichTextCallout />
        <Separator />

        {/* Import/Export & Utilities Group */}
        <RichTextExportPdf />
      </Box>
    </React.Fragment>
  );
};

export default RichTextToolbar;
