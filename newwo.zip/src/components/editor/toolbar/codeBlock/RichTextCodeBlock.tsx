import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { BiCodeBlock } from 'react-icons/bi';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextCodeBlock: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Code Block">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleCodeBlock().run()}
        className={editor.isActive('codeBlock') ? styles.isActive : ''}
      >
        <BiCodeBlock />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextCodeBlock;
