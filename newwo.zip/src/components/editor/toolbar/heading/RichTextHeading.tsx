import React, { useState } from 'react';
import { Button, Menu, MenuItem } from '@mui/material';
import { MdArrowDropDown } from 'react-icons/md';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextHeading.module.scss';

const HEADING_LEVELS = [
  { value: 'paragraph', label: 'Paragraph', level: 0 },
  { value: 'heading1', label: 'Heading 1', level: 1 },
  { value: 'heading2', label: 'Heading 2', level: 2 },
  { value: 'heading3', label: 'Heading 3', level: 3 },
  { value: 'heading4', label: 'Heading 4', level: 4 },
  { value: 'heading5', label: 'Heading 5', level: 5 },
  { value: 'heading6', label: 'Heading 6', level: 6 },
];

export const RichTextHeading: React.FC = () => {
  const editor = useRichTextEditor();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  const getCurrentHeading = () => {
    for (let i = 1; i <= 6; i++) {
      if (editor.isActive('heading', { level: i })) {
        return `Heading ${i}`;
      }
    }
    return 'Paragraph';
  };

  const handleHeadingChange = (level: number) => {
    if (level === 0) {
      editor.chain().focus().setParagraph().run();
    } else {
      editor.chain().focus().toggleHeading({ level: level as 1 | 2 | 3 | 4 | 5 | 6 }).run();
    }
    setAnchorEl(null);
  };

  return (
    <>
      <Button
        size="small"
        onClick={(e) => setAnchorEl(e.currentTarget)}
        endIcon={<MdArrowDropDown />}
        className={styles.headingButton}
      >
        {getCurrentHeading()}
      </Button>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => setAnchorEl(null)}
      >
        {HEADING_LEVELS.map((heading) => (
          <MenuItem
            key={heading.value}
            onClick={() => handleHeadingChange(heading.level)}
            selected={heading.level === 0 ? !editor.isActive('heading') : editor.isActive('heading', { level: heading.level })}
          >
            {heading.label}
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

export default RichTextHeading;
