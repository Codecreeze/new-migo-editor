import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { BiCode } from 'react-icons/bi';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextCode: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Inline Code">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleCode().run()}
        className={editor.isActive('code') ? styles.isActive : ''}
      >
        <BiCode />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextCode;
