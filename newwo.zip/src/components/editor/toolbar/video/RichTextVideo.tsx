import React, { useState, useRef } from 'react';
import { IconButton, Tooltip, Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, Tabs, Tab, Box } from '@mui/material';
import { RiVideoOnAiLine } from 'react-icons/ri';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextVideo.module.scss';

export const RichTextVideo: React.FC = () => {
  const editor = useRichTextEditor();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [videoTab, setVideoTab] = useState(0);
  const [videoUrl, setVideoUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleVideoFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check if it's a valid video file
      if (file.type.startsWith('video/')) {
        const videoUrl = URL.createObjectURL(file);
        setVideoUrl(videoUrl);
      } else {
        alert('Please select a valid video file.');
      }
    }
  };

  const handleInsertVideo = () => {
    if (videoUrl) {
      // Extract YouTube video ID if it's a YouTube URL
      const youtubeRegex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
      const match = videoUrl.match(youtubeRegex);
      
      if (match) {
        // Use YouTube extension for YouTube URLs
        editor.chain().focus().setYoutubeVideo({
          src: videoUrl,
          width: 640,
          height: 480,
        }).run();
      } else if (videoUrl.startsWith('blob:')) {
        // For local video files, insert as HTML video element with proper attributes
        const videoHtml = `
          <div style="text-align: center; margin: 16px 0;">
            <video 
              controls 
              width="640" 
              height="480" 
              style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);"
              preload="metadata"
            >
              <source src="${videoUrl}" type="video/mp4">
              <source src="${videoUrl}" type="video/webm">
              <source src="${videoUrl}" type="video/ogg">
              Your browser does not support the video tag.
            </video>
          </div>
        `;
        editor.chain().focus().insertContent(videoHtml).run();
      } else if (videoUrl.includes('vimeo.com')) {
        // Handle Vimeo URLs
        const vimeoId = videoUrl.match(/vimeo\.com\/(\d+)/)?.[1];
        if (vimeoId) {
          const vimeoHtml = `<iframe src="https://player.vimeo.com/video/${vimeoId}" width="640" height="360" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
          editor.chain().focus().insertContent(vimeoHtml).run();
        }
      } else {
        // For other video URLs, insert as iframe with better styling
        const videoHtml = `
          <div style="text-align: center; margin: 16px 0;">
            <iframe 
              src="${videoUrl}" 
              width="640" 
              height="480" 
              frameborder="0" 
              allowfullscreen
              style="max-width: 100%; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);"
            ></iframe>
          </div>
        `;
        editor.chain().focus().insertContent(videoHtml).run();
      }
    }
    setDialogOpen(false);
    setVideoUrl('');
  };

  const handleFileUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <>
      <Tooltip title="Insert Video">
        <IconButton
          size="small"
          onClick={() => setDialogOpen(true)}
          className={styles.videoButton}
        >
          <RiVideoOnAiLine />
        </IconButton>
      </Tooltip>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Insert Video</DialogTitle>
        <DialogContent>
          <Tabs value={videoTab} onChange={(_, newValue) => setVideoTab(newValue)} sx={{ mb: 2 }}>
            <Tab label="Upload File" />
            <Tab label="YouTube/URL" />
          </Tabs>

          {videoTab === 0 && (
            <Box sx={{ mt: 2 }}>
              <Button
                variant="outlined"
                onClick={handleFileUploadClick}
                fullWidth
                sx={{ mb: 2 }}
              >
                Choose Video File
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                style={{ display: 'none' }}
                onChange={handleVideoFileChange}
              />
              {videoUrl && videoUrl.startsWith('blob:') && (
                <Box sx={{ mt: 2, textAlign: 'center' }}>
                  <video
                    src={videoUrl}
                    controls
                    style={{ maxWidth: '100%', maxHeight: '200px', borderRadius: '4px' }}
                  />
                </Box>
              )}
            </Box>
          )}

          {videoTab === 1 && (
            <TextField
              autoFocus
              margin="dense"
              label="Video URL"
              fullWidth
              variant="outlined"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
              helperText="Supports YouTube URLs and other video embed URLs"
            />
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleInsertVideo} variant="contained" disabled={!videoUrl}>
            Insert
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default RichTextVideo;
