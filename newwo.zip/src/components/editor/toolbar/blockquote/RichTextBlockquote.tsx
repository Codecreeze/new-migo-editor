import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { TbBlockquote } from 'react-icons/tb';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextBlockquote: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Blockquote">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleBlockquote().run()}
        className={editor.isActive('blockquote') ? styles.isActive : ''}
      >
        <TbBlockquote />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextBlockquote;
