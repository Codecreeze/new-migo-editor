import React, { useState } from 'react';
import { Button, Menu, MenuItem } from '@mui/material';
import { MdArrowDropDown } from 'react-icons/md';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextFontSize.module.scss';

const FONT_SIZES = [
  { value: '12px', label: '12px' },
  { value: '14px', label: '14px' },
  { value: '16px', label: '16px' },
  { value: '18px', label: '18px' },
  { value: '20px', label: '20px' },
  { value: '24px', label: '24px' },
  { value: '28px', label: '28px' },
  { value: '32px', label: '32px' },
  { value: '36px', label: '36px' },
  { value: '48px', label: '48px' },
];

export const RichTextFontSize: React.FC = () => {
  const editor = useRichTextEditor();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  const getCurrentFontSize = () => {
    const fontSize = editor.getAttributes('textStyle').fontSize;
    return fontSize || '16px';
  };

  const handleFontSizeChange = (fontSize: string) => {
    editor.chain().focus().setMark('textStyle', { fontSize }).run();
    setAnchorEl(null);
  };

  return (
    <>
      <Button
        size="small"
        onClick={(e) => setAnchorEl(e.currentTarget)}
        endIcon={<MdArrowDropDown />}
        className={styles.fontSizeButton}
      >
        {getCurrentFontSize()}
      </Button>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => setAnchorEl(null)}
      >
        {FONT_SIZES.map((size) => (
          <MenuItem
            key={size.value}
            onClick={() => handleFontSizeChange(size.value)}
            style={{ fontSize: size.value }}
          >
            {size.label}
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

export default RichTextFontSize;
