import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { MdHorizontalRule } from 'react-icons/md';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextHorizontalRule.module.scss';

export const RichTextHorizontalRule: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Horizontal Rule">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().setHorizontalRule().run()}
        className={styles.horizontalRuleButton}
      >
        <MdHorizontalRule />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextHorizontalRule;
