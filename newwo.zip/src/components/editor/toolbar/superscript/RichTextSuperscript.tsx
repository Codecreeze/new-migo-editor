import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { MdSuperscript } from 'react-icons/md';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextSuperscript: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Superscript">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleSuperscript().run()}
        className={editor.isActive('superscript') ? styles.isActive : ''}
      >
        <MdSuperscript />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextSuperscript;
