import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { FaAlignLeft } from 'react-icons/fa';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextAlignLeft: React.FC = () => {
  const editor = useRichTextEditor();

  const handleAlignLeft = () => {
    editor.chain().focus().setTextAlign('left').run();
  };

  return (
    <Tooltip title="Align Left">
      <IconButton
        size="small"
        onClick={handleAlignLeft}
        className={editor.isActive({ textAlign: 'left' }) ? styles.isActive : ''}
      >
        <FaAlignLeft />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextAlignLeft;
