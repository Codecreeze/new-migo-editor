import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { LuEraser } from 'react-icons/lu';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextClear.module.scss';

export const RichTextClear: React.FC = () => {
  const editor = useRichTextEditor();

  const handleClear = () => {
    editor.chain().focus().clearContent().run();
  };

  return (
    <Tooltip title="Clear All Content">
      <IconButton
        size="small"
        onClick={handleClear}
        className={styles.clearButton}
      >
        <LuEraser />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextClear;
