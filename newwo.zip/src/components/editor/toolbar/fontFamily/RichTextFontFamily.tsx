import React, { useState } from 'react';
import { Button, Menu, MenuItem } from '@mui/material';
import { MdArrowDropDown } from 'react-icons/md';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextFontFamily.module.scss';

const FONT_FAMILIES = [
  { value: 'Inter', label: 'Inter' },
  { value: 'Arial', label: 'Arial' },
  { value: 'Georgia', label: 'Georgia' },
  { value: 'Times New Roman', label: 'Times New Roman' },
  { value: 'Courier New', label: 'Courier New' },
  { value: 'Helvetica', label: 'Helvetica' },
];

export const RichTextFontFamily: React.FC = () => {
  const editor = useRichTextEditor();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  const getCurrentFont = () => {
    const fontFamily = editor.getAttributes('textStyle').fontFamily;
    return fontFamily || 'Inter';
  };

  const handleFontChange = (fontFamily: string) => {
    editor.chain().focus().setFontFamily(fontFamily).run();
    setAnchorEl(null);
  };

  return (
    <>
      <Button
        size="small"
        onClick={(e) => setAnchorEl(e.currentTarget)}
        endIcon={<MdArrowDropDown />}
        className={styles.fontButton}
      >
        {getCurrentFont()}
      </Button>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => setAnchorEl(null)}
      >
        {FONT_FAMILIES.map((font) => (
          <MenuItem
            key={font.value}
            onClick={() => handleFontChange(font.value)}
            style={{ fontFamily: font.value }}
          >
            {font.label}
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

export default RichTextFontFamily;
