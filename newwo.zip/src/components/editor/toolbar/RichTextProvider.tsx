import React, { createContext, useContext } from 'react';
import { Editor } from '@tiptap/react';

interface RichTextContextType {
  editor: Editor;
}

const RichTextContext = createContext<RichTextContextType | null>(null);

export const useRichTextEditor = () => {
  const context = useContext(RichTextContext);
  if (!context) {
    throw new Error('useRichTextEditor must be used within a RichTextProvider');
  }
  return context.editor;
};

interface RichTextProviderProps {
  editor: Editor;
  children: React.ReactNode;
}

export const RichTextProvider: React.FC<RichTextProviderProps> = ({ editor, children }) => {
  return (
    <RichTextContext.Provider value={{ editor }}>
      {children}
    </RichTextContext.Provider>
  );
};

export default RichTextProvider;
