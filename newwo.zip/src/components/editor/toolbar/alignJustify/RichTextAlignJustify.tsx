import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { FaAlignJustify } from 'react-icons/fa';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextAlignJustify: React.FC = () => {
  const editor = useRichTextEditor();

  const handleAlignJustify = () => {
    editor.chain().focus().setTextAlign('justify').run();
  };

  return (
    <Tooltip title="Justify">
      <IconButton
        size="small"
        onClick={handleAlignJustify}
        className={editor.isActive({ textAlign: 'justify' }) ? styles.isActive : ''}
      >
        <FaAlignJustify />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextAlignJustify;
