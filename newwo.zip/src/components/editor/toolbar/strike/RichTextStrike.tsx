import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { FaStrikethrough } from 'react-icons/fa';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextStrike: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Strikethrough">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleStrike().run()}
        className={editor.isActive('strike') ? styles.isActive : ''}
      >
        <FaStrikethrough />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextStrike;
