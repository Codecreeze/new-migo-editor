import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { GrUndo } from 'react-icons/gr';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextUndo.module.scss';

export const RichTextUndo: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Undo (Ctrl+Z)">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().undo().run()}
        disabled={!editor.can().undo()}
        className={styles.undoButton}
      >
        <GrUndo />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextUndo;
