import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { GrRedo } from 'react-icons/gr';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextRedo.module.scss';

export const RichTextRedo: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Redo (Ctrl+Y)">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().redo().run()}
        disabled={!editor.can().redo()}
        className={styles.redoButton}
      >
        <GrRedo />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextRedo;
