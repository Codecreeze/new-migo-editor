import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { GoTasklist } from 'react-icons/go';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextTaskList: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Task List">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleTaskList().run()}
        className={editor.isActive('taskList') ? styles.isActive : ''}
      >
        <GoTasklist />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextTaskList;
