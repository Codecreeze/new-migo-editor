import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { ImUnderline } from 'react-icons/im';
import { useRichTextEditor } from '../RichTextProvider';
import styles from '../../SubComponents/TiptapEditor.module.scss';

export const RichTextUnderline: React.FC = () => {
  const editor = useRichTextEditor();

  return (
    <Tooltip title="Underline (Ctrl+U)">
      <IconButton
        size="small"
        onClick={() => editor.chain().focus().toggleUnderline().run()}
        className={editor.isActive('underline') ? styles.isActive : ''}
      >
        <ImUnderline />
      </IconButton>
    </Tooltip>
  );
};

export default RichTextUnderline;
