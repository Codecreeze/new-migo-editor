import React, { useState } from 'react';
import { IconButton, Tooltip, Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, Box } from '@mui/material';
import { LuReplace } from 'react-icons/lu';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextSearchAndReplace.module.scss';

export const RichTextSearchAndReplace: React.FC = () => {
  const editor = useRichTextEditor();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [replaceText, setReplaceText] = useState('');

  const handleSearch = () => {
    if (searchText) {
      // Basic search functionality - highlight text
      const content = editor.getHTML();
      const regex = new RegExp(searchText, 'gi');
      const highlightedContent = content.replace(regex, `<mark>${searchText}</mark>`);
      editor.commands.setContent(highlightedContent);
    }
  };

  const handleReplace = () => {
    if (searchText && replaceText) {
      const content = editor.getText();
      const newContent = content.replace(new RegExp(searchText, 'gi'), replaceText);
      editor.commands.setContent(newContent);
      setDialogOpen(false);
    }
  };

  return (
    <>
      <Tooltip title="Search & Replace">
        <IconButton
          size="small"
          onClick={() => setDialogOpen(true)}
          className={styles.searchButton}
        >
          <LuReplace />
        </IconButton>
      </Tooltip>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Search & Replace</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
            <TextField
              label="Search for"
              fullWidth
              variant="outlined"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              placeholder="Enter text to search"
            />
            <TextField
              label="Replace with"
              fullWidth
              variant="outlined"
              value={replaceText}
              onChange={(e) => setReplaceText(e.target.value)}
              placeholder="Enter replacement text"
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSearch} variant="outlined">Search</Button>
          <Button onClick={handleReplace} variant="contained">Replace All</Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default RichTextSearchAndReplace;
