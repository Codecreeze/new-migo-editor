import React, { useState, useRef } from 'react';
import { IconButton, Tooltip, Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, Tabs, Tab, Box } from '@mui/material';
import { RiImageAiLine } from 'react-icons/ri';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextImage.module.scss';

export const RichTextImage: React.FC = () => {
  const editor = useRichTextEditor();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [imageTab, setImageTab] = useState(0);
  const [imageUrl, setImageUrl] = useState('');
  const [imageAlt, setImageAlt] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setImageUrl(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleInsertImage = () => {
    if (imageUrl) {
      editor.chain().focus().setImage({ src: imageUrl, alt: imageAlt }).run();
    }
    setDialogOpen(false);
    setImageUrl('');
    setImageAlt('');
  };

  const handleFileUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <>
      <Tooltip title="Insert Image">
        <IconButton
          size="small"
          onClick={() => setDialogOpen(true)}
          className={styles.imageButton}
        >
          <RiImageAiLine />
        </IconButton>
      </Tooltip>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Insert Image</DialogTitle>
        <DialogContent>
          <Tabs value={imageTab} onChange={(_, newValue) => setImageTab(newValue)} sx={{ mb: 2 }}>
            <Tab label="Upload File" />
            <Tab label="URL" />
          </Tabs>

          {imageTab === 0 && (
            <Box sx={{ mt: 2 }}>
              <Button
                variant="outlined"
                onClick={handleFileUploadClick}
                fullWidth
                sx={{ mb: 2 }}
              >
                Choose Image File
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                style={{ display: 'none' }}
                onChange={handleImageFileChange}
              />
              {imageUrl && (
                <Box sx={{ mt: 2, textAlign: 'center' }}>
                  <img
                    src={imageUrl}
                    alt="Preview"
                    style={{ maxWidth: '100%', maxHeight: '200px', borderRadius: '4px' }}
                  />
                </Box>
              )}
            </Box>
          )}

          {imageTab === 1 && (
            <TextField
              autoFocus
              margin="dense"
              label="Image URL"
              fullWidth
              variant="outlined"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://example.com/image.jpg"
            />
          )}

          <TextField
            margin="dense"
            label="Alt Text"
            fullWidth
            variant="outlined"
            value={imageAlt}
            onChange={(e) => setImageAlt(e.target.value)}
            placeholder="Description of the image"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleInsertImage} variant="contained" disabled={!imageUrl}>
            Insert
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default RichTextImage;
