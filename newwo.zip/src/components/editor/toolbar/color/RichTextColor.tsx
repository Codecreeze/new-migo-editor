import React, { useState } from 'react';
import { IconButton, Tooltip, Popover, Box } from '@mui/material';
import { RiFontColor } from 'react-icons/ri';
import { useRichTextEditor } from '../RichTextProvider';
import styles from './richTextColor.module.scss';

const COLORS = [
  '#000000', '#333333', '#666666', '#999999', '#cccccc', '#ffffff',
  '#ff0000', '#ff6600', '#ffcc00', '#33cc33', '#0066cc', '#6600cc',
  '#ff3366', '#ff9933', '#ffff33', '#66ff66', '#3399ff', '#9966ff',
];

export const RichTextColor: React.FC = () => {
  const editor = useRichTextEditor();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  const handleColorChange = (color: string) => {
    editor.chain().focus().setColor(color).run();
    setAnchorEl(null);
  };

  return (
    <>
      <Tooltip title="Text Color">
        <IconButton
          size="small"
          onClick={(e) => setAnchorEl(e.currentTarget)}
          className={styles.colorButton}
        >
          <RiFontColor />
        </IconButton>
      </Tooltip>
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Box className={styles.colorPalette}>
          {COLORS.map((color) => (
            <Box
              key={color}
              className={styles.colorSwatch}
              style={{ backgroundColor: color }}
              onClick={() => handleColorChange(color)}
            />
          ))}
        </Box>
      </Popover>
    </>
  );
};

export default RichTextColor;
